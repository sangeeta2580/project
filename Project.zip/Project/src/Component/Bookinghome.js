
import React from "react";
import SaveBooking from "./SaveBooking";

class Bookinghome extends React.Component{
    render(){
        return(
                <div>
                    <SaveBooking />
                </div>

        );
    }
     

}
export default Bookinghome;